Terms Of Use

Confidentiality
You cannot send the database to any other party, nor disclose to anyone else the information contained within it as well as its structure.

Anonymisation
We have anonymised the dataset. You cannot attempt to reverse this by linking individual records with specific users. This means that you also should not link individual data with any other information about an individual that you may have. This implies that you cannot attempt to contact any individuals either.

Non-Commerical License
We grant you a non-commercial license to use the data. You can only use it for academic research that does not earn revenue, and your research also cannot be in collaboration with any commercial entities.

Recoverability
The license to use and store our data is recoverable, which means that myPersonality may ask you to cease use of it and to delete it from any storage you have at our sole discretion.